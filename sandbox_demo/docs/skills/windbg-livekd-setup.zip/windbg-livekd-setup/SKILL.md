---
name: windbg-livekd-setup
description: 在 Windows 上配置 LiveKD 内核调试环境,用 WinDbg 探索 ntoskrnl 内部结构。适用于 bcdedit /debug on 被 Secure Boot 拒绝("该值受安全引导策略保护")、或想免改 BCD/免关 Secure Boot 快速进入本地只读内核调试的场景。覆盖环境检查、符号配置、LiveKD 下载安装、启动验证和常见排错。最终用户能在 WinDbg 里用 dt/x/u/!process 等命令探索内核结构体(EPROCESS/KTHREAD 等)和反汇编。
description_zh: 配置 LiveKD 内核调试环境(WinDbg 探索 ntoskrnl)
description_en: Set up LiveKD kernel debugging environment for WinDbg
disable: false
agent_created: true
---

# windbg-livekd-setup

## When to use
- 用户想用 WinDbg 探索 Windows 内核(ntoskrnl.exe)内部结构体/反汇编,但不确定怎么搭环境。
- `bcdedit /debug on` 报错"该值受安全引导策略保护,无法进行修改或删除"(Secure Boot 阻止)。
- 用户是内核调试新手,需要从零配置符号路径、LiveKD 工具,并进入只读内核快照模式。
- 用户的目标是只读探索(看结构体、反汇编、查符号),不需要动态下断点(动态断点需要双机调试+关 Secure Boot,本 skill 不覆盖)。

## Background:为什么用 LiveKD 而不是 bcdedit /debug on
- `bcdedit /debug on` 在 Secure Boot 开启时会被拒绝,错误"该值受安全引导策略保护"。
- LiveKD(Sysinternals)不改 BCD、不关 Secure Boot,原理是创建一份内核内存快照,让 WinDbg 加载。
- LiveKD 与本地内核调试等价(都是只读),足够探索结构体/反汇编/查符号。
- 唯一限制:不能下断点/单步(和本地内核调试一样),动态跟踪需要双机调试。

## Prerequisites(前置条件)
1. Windows 10/11 x64(LiveKD 64 位版)。
2. 已安装 WinDbg(经典版 Windows SDK Debugging Tools,或 Store 版 WinDbg Preview)。
3. 管理员权限(LiveKD 需要管理员来安装驱动/创建快照)。
4. 能访问 `https://download.sysinternals.com` 和 `https://msdl.microsoft.com/download/symbols`(下载 LiveKD 和符号)。

## Steps

### 第 1 步:检查环境状态
用 PowerShell 工具(不要从 Bash 调 PowerShell,会被安全策略拦截)检查以下项,决定哪些步骤需要做:

```powershell
# 检查经典版 WinDbg
Test-Path "C:\Program Files (x86)\Windows Kits\10\Debuggers\x64\windbg.exe"
# 检查 Store 版 WinDbg Preview
Get-Command windbgx -ErrorAction SilentlyContinue
# 检查 _NT_SYMBOL_PATH(用户级 + 机器级)
[Environment]::GetEnvironmentVariable('_NT_SYMBOL_PATH','User')
[Environment]::GetEnvironmentVariable('_NT_SYMBOL_PATH','Machine')
# 检查 C:\symbols
Test-Path "C:\symbols"
# 检查 livekd64 是否已在 PATH
Get-Command livekd64 -ErrorAction SilentlyContinue
# 检查是否管理员
$id=[System.Security.Principal.WindowsIdentity]::GetCurrent();$pr=New-Object System.Security.Principal.WindowsPrincipal($id);$pr.IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator)
```

注意:PowerShell 工具输出有时不回显,可把结果 `Set-Content` 写到 `$env:TEMP\xxx.txt` 再用 Read 工具读取。

### 第 2 步:配置符号路径
```powershell
# 创建符号缓存目录
New-Item -ItemType Directory -Path "C:\symbols" -Force | Out-Null
# 设置用户级环境变量(永久,新 shell 生效)
[Environment]::SetEnvironmentVariable('_NT_SYMBOL_PATH', 'srv*c:\symbols*https://msdl.microsoft.com/download/symbols', 'User')
```
- 符号路径格式:`srv*<本地缓存目录>*<符号服务器URL>`
- 设成 User 级(不需要管理员也能读;Machine 级需要管理员)。

### 第 3 步:下载并安装 LiveKD
```powershell
$dir = "C:\Tools\LiveKD"
New-Item -ItemType Directory -Path $dir -Force | Out-Null
$url = "https://download.sysinternals.com/files/LiveKD.zip"
$zip = "$dir\LiveKD.zip"
Invoke-WebRequest -Uri $url -OutFile $zip -UseBasicParsing
Expand-Archive -Path $zip -DestinationPath $dir -Force
# 验证 livekd64.exe 存在
Test-Path "$dir\livekd64.exe"
```
- 下载可能要 30 秒~1 分钟(约 500KB 压缩包)。Invoke-WebRequest 默认有进度输出,正常。

### 第 4 步:启动 LiveKD
**关键:必须在新的 PowerShell 会话里启动,让第 2 步设的 _NT_SYMBOL_PATH 环境变量生效(setx/SetEnvironmentVariable 在当前会话不即时生效)。**

```powershell
# 在新会话里,显式设置本次进程的环境(PATH 加 WinDbg,符号路径显式传)
$env:PATH = "C:\Program Files (x86)\Windows Kits\10\Debuggers\x64;" + $env:PATH
$env:_NT_SYMBOL_PATH = "srv*c:\symbols*https://msdl.microsoft.com/download/symbols"
Set-Location "C:\Tools\LiveKD"
# 后台启动(livekd64 会弹出 WinDbg GUI 窗口)
Start-Process -FilePath "C:\Tools\LiveKD\livekd64.exe" -ArgumentList "-w" -WorkingDirectory "C:\Tools\LiveKD"
```

- `-w` 表示用 WinDbg 打开(默认也可能是)。
- 启动后会出现两个进程:`livekd64`(创建快照)和 `windbg`(加载快照)。
- 首次启动慢:要从微软符号服务器下载 ntoskrnl PDB(几十 MB),看网速 30 秒~几分钟。
- WinDbg 窗口左下角命令栏会从 `*BUSY*` 变成 `lkd>`,表示加载完成。

### 第 5 步:验证成功
在弹出的 WinDbg 窗口命令栏(`lkd>`)敲:
```
lm
```
输出里应该有 `nt` 模块,且带 `(pdb symbols)` 标记,例如:
```
nt         (pdb symbols)          c:\symbols\ntkrnlmp.pdb\<hash>\ntkrnlmp.pdb
```
看到这行 = 成功。然后可以开始探索:
```
dt nt!_EPROCESS       # 看进程结构布局
u nt!NtCreateFile     # 反汇编
```

## 日常启动(环境已配置过,以后每次怎么开)
首次配置完成后,以后每次启动只需:
1. **右键以管理员身份运行** `C:\Tools\LiveKD\start-livekd.cmd`(一键脚本,自动设 PATH/符号/启动)。
2. 等 WinDbg 窗口弹出,左下角 `*BUSY*` 变 `lkd>` 即可。
3. 用完直接关 WinDbg 窗口。

**重要:start-livekd.cmd 必须是纯英文(无中文注释/echo)**。中文在 cmd(GBK 编码)下会乱码,导致 `'s"'` 之类的报错脚本闪退。脚本的说明文字放 SKILL.md 或对话里,不要放脚本里。

如果没有一键脚本,手动方式(管理员 PowerShell,推荐备用):
```powershell
$env:PATH = "C:\Program Files (x86)\Windows Kits\10\Debuggers\x64;" + $env:PATH
$env:_NT_SYMBOL_PATH = "srv*c:\symbols*https://msdl.microsoft.com/download/symbols"
cd C:\Tools\LiveKD
.\livekd64.exe -w
```

## Pitfalls(常见坑)

1. **`bcdedit /debug on` 报"该值受安全引导策略保护"** → Secure Boot 阻止。本 skill 的 LiveKD 方案就是为绕开它,不用关 Secure Boot。

2. **`Unable to load image \??\C:\WINDOWS\system32\Drivers\LiveKdD.SYS`** → **这是无害告警,不是致命错误**。LiveKdD.sys 是 LiveKD 的辅助驱动,WinDbg 解析不到它的镜像/符号会抱怨,但快照已成功加载。只要 `lm` 能看到 `nt` 模块就说明一切正常,忽略这条。

3. **setx / SetEnvironmentVariable 在当前 shell 不生效** → 环境变量改动只对新进程生效。第 4 步启动 livekd 时要么开新 shell,要么在脚本里显式 `$env:_NT_SYMBOL_PATH = "..."`。

4. **PowerShell 工具输出不回显** → 把结果用 `Set-Content -Path "$env:TEMP\xxx.txt"` 写文件,再用 Read 工具读。

5. **livekd64 找不到 windbg.exe** → WinDbg 不在 PATH 里。第 4 步启动前必须 `$env:PATH = "C:\Program Files (x86)\Windows Kits\10\Debuggers\x64;" + $env:PATH`(或对应安装路径)。

6. **没有管理员权限** → LiveKD 安装驱动需要管理员。右键"以管理员身份运行"PowerShell。

7. **首次启动卡很久** → 正常,在下载 ntoskrnl PDB。看 WinDbg 窗口左下角,`*BUSY*` 变 `lkd>` 就好了。

8. **想要动态下断点/单步** → LiveKD 和本地内核调试都做不到,必须双机调试(虚拟机+命名管道/网络)+ 关 Secure Boot。本 skill 不覆盖这个进阶场景。

9. **`!process 0 0` / `!handle 0 f` 等遍历命令会把 LiveKD 搞崩** → LiveKD 快照模式下,遍历所有进程/句柄会让 livekd64 进程访问违例退出,WinDbg 随之失去数据源崩溃。**在 LiveKD 下绝对不要用遍历类命令**。改用:
   - `dt nt!_EPROCESS` 看结构布局(不遍历实例,安全)
   - `dt nt!_EPROCESS <具体地址>` 看单个进程实例
   - `!process -1 0` 看当前进程(只一个)
   - `u nt!NtCreateFile` 反汇编单个函数
   - `x nt!*EPROCESS*` 通配查符号

10. **livekd64 进程退出 = WinDbg 会崩** → LiveKD 的快照数据源由 livekd64 进程维持。如果它退出(被关/崩溃/遍历命令搞挂),WinDbg 失去数据源会崩。表现为 WinDbg 窗口消失。解法:重启 LiveKD(见"日常启动")。

11. **start-livekd.cmd 含中文会闪退** → cmd 默认 GBK 编码,UTF-8 脚本里的中文被错位解析,报 `'s"'` 之类错误后闪退。**脚本必须纯英文**。残留的 windbg/livekd64 进程也会导致新启动失败,启动前先清理残留进程。

12. **脚本闪退排查** → 在脚本末尾加 `pause` 让窗口停住看报错;确认 windbg.exe/livekd64.exe 路径存在;确认管理员权限;确认没有残留 windbg/livekd64 进程占着 LiveKdD.sys。

## Verification(验证清单)
- [ ] `C:\symbols` 目录存在
- [ ] `_NT_SYMBOL_PATH` 用户级环境变量 = `srv*c:\symbols*https://msdl.microsoft.com/download/symbols`
- [ ] `C:\Tools\LiveKD\livekd64.exe` 存在
- [ ] livekd64 进程 + windbg 进程都在运行
- [ ] WinDbg 命令栏显示 `lkd>`(不是 `*BUSY*`)
- [ ] `lm` 输出包含 `nt (pdb symbols)` 行

全部满足 = 环境配置成功,可开始探索 ntoskrnl。

## 探索起点(配置成功后建议的第一组命令)
```
lm                          # 确认 nt 模块加载
dt nt!_EPROCESS             # 进程结构(对应沙箱的 Token/Job/MitigationFlags 字段)
dt nt!_KTHREAD              # 内核线程
u nt!NtCreateFile           # 反汇编一个 syscall 实现
```
**不要用** `!process 0 0` / `!handle 0 f` / `!object \` —— 这些遍历命令在 LiveKD 下会把 livekd64 进程搞崩(见 Pitfall 9)。
